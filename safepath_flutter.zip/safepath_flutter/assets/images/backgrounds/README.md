# Backgrounds Directory

This directory contains background images and textures for the app.

## Current Backgrounds:
- App background images
- Screen backgrounds
- Texture patterns
- Gradient overlays

## Naming Convention:
Use descriptive names like:
- `main_background.png`
- `gradient_overlay.png`
- `texture_pattern.png`
- `city_background.jpg`
