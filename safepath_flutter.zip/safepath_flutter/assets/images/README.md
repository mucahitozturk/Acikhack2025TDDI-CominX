# Assets Images Directory

This directory contains all the images used in the SafePath Flutter application.

## Structure:
- `icons/` - App icons and small graphics
- `backgrounds/` - Background images and textures
- `screenshots/` - App screenshots and mockups

## Supported formats:
- PNG (recommended for icons and graphics)
- JPG/JPEG (for photos and backgrounds)
- SVG (for scalable vector graphics)

## Usage:
To use images in your Flutter code, reference them like this:
```dart
Image.asset('assets/images/icons/icon_name.png')
```
