# Icons Directory

This directory contains app icons and small graphics.

## Current Icons:
- App launcher icons
- Navigation icons
- Feature icons
- Status icons

## Naming Convention:
Use descriptive names like:
- `home_icon.png`
- `location_pin.png`
- `accessibility_icon.png`
- `download_icon.png`
