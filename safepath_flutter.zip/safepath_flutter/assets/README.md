# SafePath Assets Directory

This directory contains all the assets used in the SafePath Flutter application.

## Directory Structure

```
assets/
├── images/
│   ├── icons/           # App icons and small graphics
│   │   ├── placeholder_icon.png
│   │   └── README.md
│   ├── backgrounds/     # Background images and textures
│   │   ├── gradient_background.png
│   │   └── README.md
│   └── README.md
├── fonts/               # Custom fonts
│   └── README.md
└── README.md
```

## Asset Types

### Images
- **Icons**: Navigation icons, feature icons, status indicators
- **Backgrounds**: Screen backgrounds, textures, overlays
- **Screenshots**: App mockups and design references

### Fonts
- **SF Pro Display**: Main application font family
- **Alternative fonts**: For different languages and accessibility

## Usage in Flutter

### Loading Images
```dart
// Load an image asset
Image.asset('assets/images/icons/placeholder_icon.png')

// Load with error handling
Image.asset(
  'assets/images/backgrounds/gradient_background.png',
  errorBuilder: (context, error, stackTrace) {
    return Container(
      color: Colors.grey,
      child: Icon(Icons.error),
    );
  },
)
```

### Loading Fonts
```dart
// Use custom font in TextStyle
Text(
  'Hello World',
  style: TextStyle(
    fontFamily: 'SF Pro Display',
    fontWeight: FontWeight.bold,
  ),
)
```

## Adding New Assets

1. Place your asset file in the appropriate subdirectory
2. Update this README if adding new asset types
3. Run `flutter pub get` to refresh asset references
4. Use the asset in your Flutter code

## Supported Formats

- **Images**: PNG, JPG/JPEG, SVG, WebP
- **Fonts**: OTF, TTF, WOFF, WOFF2
- **Other**: JSON, XML, TXT (for configuration files)

## Best Practices

- Use descriptive file names
- Optimize images for mobile (compress when possible)
- Keep assets organized in logical subdirectories
- Document any special usage requirements
- Test assets on different screen densities
