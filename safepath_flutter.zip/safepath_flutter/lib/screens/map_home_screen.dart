import 'package:flutter/material.dart';
import 'chatbot_screen.dart';
import 'dart:async';
// ignore: avoid_web_libraries_in_flutter
import 'dart:html' as html;
import 'dart:ui_web' as ui_web;
import 'package:flutter/foundation.dart' show kIsWeb;
import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:flutter/scheduler.dart';

class MapHomeScreen extends StatefulWidget {
  const MapHomeScreen({super.key});

  @override
  State<MapHomeScreen> createState() => _MapHomeScreenState();
}

class _MapHomeScreenState extends State<MapHomeScreen> {
  Timer? _timer;
  bool _showMap = false;
  bool _isRecording = false;
  dynamic _mediaRecorder;
  List<int> _audioChunks = [];

  @override
  void initState() {
    super.initState();
    _initializeMap();
    _setupAudioListener();
  }
  
  void _setupAudioListener() {
    if (kIsWeb) {
      // JavaScript'ten gelen ses kaydetme mesajlarını dinle
      html.window.addEventListener('message', _messageHandler);
    }
  }

  void _initializeMap() {
    if (kIsWeb) {
      print('🔍 Initializing Google Maps for web in MapHomeScreen...');
      ui_web.platformViewRegistry.registerViewFactory(
        'map-home',
        (int viewId) {
          print('🏗️ Creating Google Maps div for MapHomeScreen...');
          final mapDiv = html.DivElement()
            ..id = "map-home"
            ..style.width = "100%"
            ..style.height = "100%";
          
          print('✅ Google Maps div created successfully for MapHomeScreen');
          return mapDiv;
        },
      );
      print('✅ View factory registered successfully for MapHomeScreen');
    } else {
      print('❌ Not running on web platform');
    }

    // Map'i gösterme zamanlayıcısı
    _timer = Timer(const Duration(seconds: 3), () {
      if (mounted) {
        print('⏰ Timer completed, showing map in MapHomeScreen...');
        setState(() {
          _showMap = true;
        });
        print('✅ Map state set to true in MapHomeScreen');
      }
    });
  }

  @override
  void dispose() {
    _timer?.cancel();
    
    // Event listener'ı temizle
    if (kIsWeb) {
      html.window.removeEventListener('message', _messageHandler);
    }
    
    super.dispose();
  }
  
  // Message handler'ı ayrı bir fonksiyon olarak tanımla
  void _messageHandler(html.Event event) {
    // Widget dispose edilmişse hiçbir şey yapma
    if (!mounted) return;
    
    try {
      final messageEvent = event as html.MessageEvent;
      print('📨 Flutter received message: ${messageEvent.data}');
      
      if (messageEvent.data is String && messageEvent.data.startsWith('{')) {
        // JSON mesaj - detaylı ses bilgisi
        try {
          final audioInfo = jsonDecode(messageEvent.data);
          if (audioInfo['type'] == 'audioProcessed') {
            final duration = audioInfo['duration'] ?? 0;
            final fileSize = audioInfo['fileSize'] ?? '0';
            final format = audioInfo['format'] ?? 'unknown';
            
            WidgetsBinding.instance.addPostFrameCallback((_) {
              if (mounted && context.mounted) {
                _showSuccessMessage('Ses kaydı tamamlandı! (${duration}s, ${fileSize} KB)');
              }
            });
          }
        } catch (e) {
          print('❌ Error parsing JSON message: $e');
        }
      } else if (messageEvent.data == 'audioProcessed') {
        // Basit mesaj - geriye uyumluluk
        WidgetsBinding.instance.addPostFrameCallback((_) {
          if (mounted && context.mounted) {
            _showSuccessMessage('Ses kaydı başarıyla işlendi!');
          }
        });
      } else if (messageEvent.data == 'audioError') {
        // Ses kaydı hatası - güvenli şekilde göster
        WidgetsBinding.instance.addPostFrameCallback((_) {
          if (mounted && context.mounted) {
            _showErrorMessage('Ses kaydı işlenirken hata oluştu');
          }
        });
      }
    } catch (e) {
      print('❌ Error in message handler: $e');
    }
  }

  // Ses kaydetme fonksiyonu - basitleştirilmiş versiyon
  void _startRecording() {
    if (kIsWeb) {
      html.window.console.log('🎤 Flutter: Starting audio recording...');
      // JavaScript ile ses kaydını başlat
      html.window.postMessage('startRecording', '*');
      setState(() {
        _isRecording = true;
      });
    }
  }

  // Ses kaydını durdur
  void _stopRecording() {
    if (kIsWeb) {
      html.window.console.log('⏹️ Flutter: Stopping audio recording...');
      // JavaScript ile ses kaydını durdur
      html.window.postMessage('stopRecording', '*');
      setState(() {
        _isRecording = false;
      });
    }
  }

  // Başarı mesajı göster
  void _showSuccessMessage(String message) {
    try {
      if (mounted && context.mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(message),
            backgroundColor: Colors.green,
            duration: const Duration(seconds: 3),
          ),
        );
      }
    } catch (e) {
      // Widget dispose edilmişse hiçbir şey yapma
      print('Widget disposed, cannot show success message');
    }
  }

  // Hata mesajı göster
  void _showErrorMessage(String message) {
    try {
      if (mounted && context.mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(message),
            backgroundColor: Colors.red,
            duration: const Duration(seconds: 3),
          ),
        );
      }
    } catch (e) {
      // Widget dispose edilmişse hiçbir şey yapma
      print('Widget disposed, cannot show error message');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration: const BoxDecoration(
          image: DecorationImage(
            image: AssetImage('assets/images/backgrounds/background1.jpg'),
            fit: BoxFit.cover,
          ),
        ),
        child: SafeArea(
          child: Column(
            children: [
              // Status Bar
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  const Text(
                    '9:12',
                    style: TextStyle(
                      fontSize: 17,
                      fontWeight: FontWeight.w600,
                      color: Colors.white,
                    ),
                  ),
                  Row(
                    children: [
                      const Icon(Icons.signal_cellular_4_bar, size: 16, color: Colors.white),
                      const SizedBox(width: 4),
                      const Icon(Icons.wifi, size: 16, color: Colors.white),
                      const SizedBox(width: 4),
                      const Icon(Icons.battery_full, size: 20, color: Colors.white),
                    ],
                  ),
                ],
              ),
              const SizedBox(height: 10),
              
              // Google Maps with Floating Action Buttons
              Expanded(
                child: Stack(
                  children: [
                    // Google Maps
                    Container(
                      margin: const EdgeInsets.symmetric(horizontal: 20),
                      decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.circular(15),
                        boxShadow: [
                          BoxShadow(
                            color: Colors.black.withOpacity(0.2),
                            blurRadius: 15,
                            offset: const Offset(0, 4),
                          ),
                        ],
                      ),
                      child: ClipRRect(
                        borderRadius: BorderRadius.circular(15),
                        child: _showMap
                            ? HtmlElementView(
                                viewType: 'map-home',
                              )
                            : Container(
                                color: Colors.blue[100],
                                child: const Center(
                                  child: CircularProgressIndicator(
                                    valueColor: AlwaysStoppedAnimation<Color>(
                                        Color(0xFF871616)),
                                  ),
                                ),
                              ),
                      ),
                    ),
                    
                    // Floating Action Buttons
                    Positioned(
                      top: 20,
                      right: 40,
                      child: Column(
                        children: [
                          // Refresh Button
                          Container(
                            width: 50,
                            height: 50,
                            decoration: BoxDecoration(
                              color: const Color(0xFF871616),
                              shape: BoxShape.circle,
                              boxShadow: [
                                BoxShadow(
                                  color: Colors.black.withOpacity(0.3),
                                  blurRadius: 15,
                                  offset: const Offset(0, 4),
                                ),
                              ],
                            ),
                            child: IconButton(
                              onPressed: () {
                                // Refresh map data
                                if (kIsWeb) {
                                  // Call the global JavaScript function using js context
                                  html.window.console.log('🔄 Refreshing map data...');
                                  // Use js.context to call the global function
                                  html.window.console.log('Calling refreshMapData...');
                                  // For now, just log - the function will be called automatically
                                }
                              },
                              icon: const Icon(
                                Icons.refresh,
                                color: Colors.white,
                                size: 24,
                              ),
                            ),
                          ),
                          const SizedBox(height: 15),
                          // Menu Button
                          Container(
                            width: 50,
                            height: 50,
                            decoration: BoxDecoration(
                              color: const Color(0xFF871616),
                              shape: BoxShape.circle,
                              boxShadow: [
                                BoxShadow(
                                  color: Colors.black.withOpacity(0.3),
                                  blurRadius: 15,
                                  offset: const Offset(0, 4),
                                ),
                              ],
                            ),
                            child: const Icon(
                              Icons.layers,
                              color: Colors.white,
                              size: 24,
                            ),
                          ),
                          const SizedBox(height: 15),
                          // Location Button
                          Container(
                            width: 50,
                            height: 50,
                            decoration: BoxDecoration(
                              color: const Color(0xFF871616),
                              shape: BoxShape.circle,
                              boxShadow: [
                                BoxShadow(
                                  color: Colors.black.withOpacity(0.3),
                                  blurRadius: 15,
                                  offset: const Offset(0, 4),
                                ),
                              ],
                            ),
                            child: const Icon(
                              Icons.my_location,
                              color: Colors.white,
                              size: 24,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
              
              // Chat Input Area
              Container(
                margin: const EdgeInsets.symmetric(horizontal: 20, vertical: 8),
                padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 12),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(25),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.black.withOpacity(0.1),
                      blurRadius: 10,
                      offset: const Offset(0, 2),
                    ),
                  ],
                ),
                child: Row(
                  children: [
                    // Ses kaydetme butonu
                    GestureDetector(
                      onTap: _isRecording ? _stopRecording : _startRecording,
                      child: Container(
                        width: 36,
                        height: 36,
                        decoration: BoxDecoration(
                          color: _isRecording ? Colors.red : const Color(0xFF871616),
                          shape: BoxShape.circle,
                        ),
                        child: Icon(
                          _isRecording ? Icons.stop : Icons.mic,
                          color: Colors.white,
                          size: 18,
                        ),
                      ),
                    ),
                    const SizedBox(width: 12),
                    // Text input alanı
                    Expanded(
                      child: TextField(
                        decoration: InputDecoration(
                          hintText: 'Sohbet için mesajınızı yazın...',
                          hintStyle: TextStyle(
                            color: Colors.grey[400],
                            fontSize: 14,
                          ),
                          border: InputBorder.none,
                          contentPadding: EdgeInsets.zero,
                        ),
                        style: const TextStyle(
                          fontSize: 14,
                          color: Colors.black87,
                        ),
                      ),
                    ),
                    const SizedBox(width: 10),
                    // Gönder butonu
                    GestureDetector(
                      onTap: () {
                        // Navigate to chatbot screen
                        Navigator.push(
                          context,
                          MaterialPageRoute(builder: (context) => const ChatbotScreen()),
                        );
                      },
                      child: Container(
                        width: 36,
                        height: 36,
                        decoration: BoxDecoration(
                          color: const Color(0xFF871616),
                          shape: BoxShape.circle,
                        ),
                        child: const Icon(
                          Icons.send,
                          color: Colors.white,
                          size: 18,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
              
              // Bottom Content Card
              Container(
                margin: const EdgeInsets.all(16),
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(18),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.black.withOpacity(0.2),
                      blurRadius: 20,
                      offset: const Offset(0, -6),
                    ),
                  ],
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    // Date
                    Text(
                      'Pazar, 6 Şubat',
                      style: TextStyle(
                        fontSize: 14,
                        color: Colors.grey[600],
                      ),
                    ),
                    const SizedBox(height: 8),
                    
                    // Main Question
                    const Text(
                      'Bugün nereye gidiyorsun?',
                      style: TextStyle(
                        fontSize: 20,
                        fontWeight: FontWeight.bold,
                        color: Colors.black,
                      ),
                    ),
                    const SizedBox(height: 16),
                    
                    // Category Buttons
                    Column(
                      children: [
                        Row(
                          children: [
                            Expanded(
                              child: _buildCategoryButton(
                                'Kayıtlı Yerler',
                                Icons.favorite,
                                Colors.pink,
                                () {},
                              ),
                            ),
                            const SizedBox(width: 10),
                            Expanded(
                              child: _buildCategoryButton(
                                'Güvenli Alan Bul',
                                Icons.work,
                                Colors.green,
                                () {
                                  // Show safe areas with overlapping green circles
                                  if (kIsWeb) {
                                    html.window.console.log('🟢 Flutter: Showing safe areas...');
                                    html.window.console.log('🟢 Flutter: Sending postMessage...');
                                    // Call the JavaScript function using postMessage
                                    html.window.postMessage('showSafeAreas', '*');
                                    html.window.console.log('🟢 Flutter: postMessage sent');
                                    
                                    // Alternative method: try direct function call
                                    html.window.console.log('🟢 Flutter: Trying alternative method...');
                                    try {
                                      // Wait a bit and then try direct call
                                      Timer(const Duration(milliseconds: 100), () {
                                        if (kIsWeb) {
                                          html.window.console.log('🟢 Flutter: Calling testSafeAreas...');
                                          // Use postMessage as alternative
                                          html.window.postMessage('testSafeAreas', '*');
                                        }
                                      });
                                    } catch (e) {
                                      html.window.console.log('🟢 Flutter: Alternative method failed');
                                    }
                                  }
                                },
                              ),
                            ),
                            const SizedBox(width: 10),
                            Expanded(
                              child: _buildCategoryButton(
                                'Ev',
                                Icons.home,
                                Colors.purple,
                                () {},
                              ),
                            ),
                          ],
                        ),
                        const SizedBox(height: 10),
                        Row(
                          children: [
                            Expanded(
                              child: _buildCategoryButton(
                                'Kafe',
                                Icons.local_cafe,
                                Colors.orange,
                                () {},
                              ),
                            ),
                            const SizedBox(width: 10),
                            Expanded(
                              child: _buildCategoryButton(
                                'Bölgeleri Göster',
                                Icons.map,
                                Colors.blue,
                                () {
                                  // Show regions with normal markers
                                  if (kIsWeb) {
                                    html.window.console.log('📍 Showing regions...');
                                    // Call the JavaScript function using postMessage
                                    html.window.postMessage('showRegions', '*');
                                  }
                                },
                              ),
                            ),
                            const SizedBox(width: 10),
                            Expanded(
                              child: Container(), // Empty space for balance
                            ),
                          ],
                        ),
                      ],
                    ),
                  ],
                ),
              ),
              
              // Home Indicator
              Container(
                width: 120,
                height: 4,
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(2),
                ),
              ),
              const SizedBox(height: 6),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildCategoryButton(String text, IconData icon, Color color, VoidCallback onTap) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        height: 50,
        decoration: BoxDecoration(
          color: color.withOpacity(0.1),
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: color.withOpacity(0.3)),
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(icon, color: color, size: 18),
            const SizedBox(height: 3),
            Text(
              text,
              style: TextStyle(
                fontSize: 9,
                fontWeight: FontWeight.w500,
                color: color,
              ),
              textAlign: TextAlign.center,
            ),
          ],
        ),
      ),
    );
  }
}
