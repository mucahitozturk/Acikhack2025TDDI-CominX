import 'package:flutter/material.dart';
import 'screens/accessibility_screen.dart';
import 'screens/start_screen.dart';
import 'screens/download_map_screen.dart';
import 'screens/map_home_screen.dart';
import 'screens/chatbot_screen.dart';

void main() {
  runApp(const MainApp());
}

class MainApp extends StatelessWidget {
  const MainApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'SafePath',
      theme: ThemeData(
        primarySwatch: Colors.blue,
        fontFamily: 'Roboto', // Using default system font
      ),
      home: const AccessibilityScreen(),
      debugShowCheckedModeBanner: false,
      routes: {
        '/accessibility': (context) => const AccessibilityScreen(),
        '/start': (context) => const StartScreen(),
        '/download': (context) => const DownloadMapScreen(),
        '/map_home': (context) => const MapHomeScreen(),
        '/chatbot': (context) => const ChatbotScreen(),
      },
    );
  }
}
