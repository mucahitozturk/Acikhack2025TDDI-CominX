package com.example.safepath

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
