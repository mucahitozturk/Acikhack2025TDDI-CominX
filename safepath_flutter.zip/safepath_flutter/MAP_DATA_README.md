# SafePath Map Data Integration

Bu uygulama, Google Maps üzerinde API'den gelen veri noktalarını göstermek için tasarlanmıştır.

## Özellikler

- Google Maps entegrasyonu
- API'den veri noktalarını çekme (`http://localhost:8000/api/veriler`)
- Her nokta için detaylı bilgi gösterimi (mahal adı, ilçe, koordinatlar)
- Refresh butonu ile veri yenileme
- Responsive tasarım

## API Veri Formatı

API'den beklenen veri formatı:

```json
[
  {
    "x": 29.070713660149135,
    "y": 40.87939910569092,
    "mahal_adi": "BURGAZ ADA",
    "ilce": "ADALAR"
  }
]
```

- `x`: Boylam (longitude)
- `y`: Enlem (latitude)
- `mahal_adi`: Yer adı
- `ilce`: İlçe adı

## Kullanım

1. Uygulamayı başlatın
2. Harita otomatik olarak yüklenecek ve veri noktaları gösterilecek
3. Her noktaya tıklayarak detay bilgilerini görüntüleyebilirsiniz
4. Sağ üstteki refresh butonuna tıklayarak verileri yenileyebilirsiniz

## Teknik Detaylar

- Flutter Web kullanılarak geliştirildi
- Google Maps JavaScript API entegrasyonu
- HTML element view ile harita gösterimi
- Marker yönetimi ve info window'lar
- Hata durumunda örnek veri kullanımı

## Gereksinimler

- Flutter SDK
- Google Maps API Key
- API endpoint (`http://localhost:8000/api/veriler`)

## Kurulum

1. Projeyi klonlayın
2. `flutter pub get` komutunu çalıştırın
3. Google Maps API key'ini `web/index.html` dosyasında güncelleyin
4. `flutter run -d chrome` ile uygulamayı başlatın

## Notlar

- API erişilemez olduğunda örnek veriler kullanılır
- Harita zoom seviyesi 10 olarak ayarlanmıştır
- Merkez nokta İstanbul olarak belirlenmiştir
- Tüm marker'lar kırmızı renkte gösterilir
